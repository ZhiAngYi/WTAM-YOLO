from ultralytics import YOLO
import warnings
warnings.filterwarnings('ignore')


# 多线程添加代码
if __name__ == '__main__':
    # 不加载预训练模型
    model = YOLO(r'yolo11n.yaml')
    # model = YOLO(r'yolo6n.yaml', task='detect')
    # 训练模型
    model.train(data=r'/home/user/zhangyi/YOLO11/datasets/feijiejie/feijiejie.yaml',
                # seed=42,
                # lr0=0.01,
                lr0=0.0005,  # 降低初始学习率
                # lrf=0.1,  # 学习率预热系数
                epochs=300,
                batch=16,
                imgsz=640,
                device=0,
                workers=4,
                patience=300,
                project=r'/home/user/zhangyi/YOLO11/duibi/jieguo',
                name='yolo11_BASE',  # <== 自定义文件夹名



    )
